package com.healen.test;

import java.io.IOException;
import org.openqa.selenium.By;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.healen.main.BasePage;
import com.healen.main.HealEnPage;

public class DataDrivenTest extends BasePage {
	
	//Login
	By username = By.id("inputEmail");
	By password = By.id("inputPassword");
	By signInBtn = By.xpath("//button[text()='Sign in']");
	
	//Logout
	By openMenu = By.cssSelector("[src='https://healen-ui.s3.ap-south-1.amazonaws.com/assets/images/menuicon.png']");
	By logoutBtn = By.xpath("//*[text()='Logout']");
	By confirmLogout = By.xpath("//*[text()='Yes, logout!']");
	
	By loadingIcon = By.cssSelector(".loadingSection");
	By loadingIconDark = By.cssSelector(".spinner-border.text-dark");
	
	HealEnPage page = new HealEnPage();

	@BeforeClass
	public void setUp() {
		initialization();
	}

	@DataProvider
	public Object[][] getExcelData() {
		Object data[][] = getTestData("Login");
		return data;
	}

	@Test(dataProvider = "getExcelData")
	public void Test1(String UserNumber, String userid, String pwd,String bodyPart,String diagnosisList,String priorityflag, String painIntensity, String wholeProblemDay, String episodeDays, String subPart,String flexibilityAnswer,String ageGroup,String neckAlignmentAnswer,String backAlignmentAnswer,String pelvisAlignmentAnswer,String diffInLegs,String kneeAlignmentAnswer,String kneeAlignmentAnswer2,String footAlignmentAnswer,String runSessions,String sessionTime,String feedback) throws InterruptedException, IOException {
		type(username, userid);
		//type(username, prop.getProperty("Userid"));
		type(password, pwd);
		click(signInBtn);
		waitForStaleness(loadingIcon);
		page.createComplaint(UserNumber,priorityflag,bodyPart, diagnosisList, subPart,painIntensity,wholeProblemDay,episodeDays,flexibilityAnswer,ageGroup,neckAlignmentAnswer,backAlignmentAnswer, pelvisAlignmentAnswer,diffInLegs,kneeAlignmentAnswer,kneeAlignmentAnswer2, footAlignmentAnswer);
		page.createSession(UserNumber,IntegerConverter(runSessions),IntegerConverter(sessionTime),feedback);
		click(openMenu);
		click(logoutBtn);
		click(confirmLogout);
	}

	@AfterClass
	public void tearDown() {
		driver.quit();
	}
}
