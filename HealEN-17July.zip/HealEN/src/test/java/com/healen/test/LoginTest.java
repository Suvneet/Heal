package com.healen.test;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.healen.main.LoginPage;

public class LoginTest extends LoginPage {
	
	@BeforeMethod
	public void setUp() {
		initialization();
	}

	@Test(enabled = true, groups = {"Login" }, 
			description = "Verify that whether system displaying the homepage once user visit to Aktivehealth site.")
	public void LoginTest01_verifyPageTitle() {
		String title = getLoginTitle();
		Assert.assertEquals("HealEN", title,"[Failed] : Login Page title is not correct.");
	}
	
	@Test(enabled = true, groups = {"Login" }, 
			description = "Verify that whether system allows valid Email Id in email address field")
	public void LoginTest02_invalidEmailCheck() {
		boolean flag = invalidEmailError("#");
		Assert.assertEquals(true, flag ,"[Failed] : Login Page invalid email error is not showing.");
	}
	
	@Test(enabled = true, groups = {"Login" }, 
			description = "Verify that whether system allows empty Email Id in email address field ")
	public void LoginTest03_emptyEmailCheck() {
		boolean flag = emptyEmailError("");
		Assert.assertEquals(true, flag ,"[Failed] : Login Page empty email error is not showing.");
	}
	
	@Test(enabled = true, groups = {"Login" }, 
			description = "Verify that whether system allows empty password in email address field ")
	public void LoginTest04_emptyPasswordCheck() {
		boolean flag = emptyPasswordError("");
		Assert.assertEquals(true, flag ,"[Failed] : Login Page empty password error is not showing.");
	}
	
	@Test(enabled = true, groups = {"Login" }, 
			description = "Verify that whether system allows to reset the passward using forgot passward link.")
	public void LoginTest05_forgotPasswordCheck() throws InterruptedException {
		String title = checkForgotPassword();
		Assert.assertEquals(true, title.contains("enter-registered-email"),"[Failed] : Login Page,forgot passward link is not working");
	}
	
	@Test(enabled = true, groups = {"Login" }, 
			description = "Verify that whether system allows to create the new user in application using valid data inputting")
	public void LoginTest06_validCredentialsCheck() throws InterruptedException {
		String title = loginWithValidCredentials(prop.getProperty("Userid"),prop.getProperty("password"));
		Assert.assertEquals(true, !title.contains("login"),"[Failed] : User is not able to login with valid credentials.");
	}

	@AfterMethod
	public void tearDown() {
		driver.quit();
	}
}
