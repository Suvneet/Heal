package com.healen.main;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.InputEvent;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.DecimalFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BasePage {

	public static WebDriver driver;
	public static Properties prop;
	static WebDriverWait exp_wait;

	public static String TESTDATA_SHEET_PATH = "/src/main/resources/HealEn_data.xlsx";
	public static String OUTPUT_SHEET_PATH = "/src/main/resources/HealEn_output.xlsx";
	
	static Workbook book;
	static Sheet sheet;

	public BasePage() {
		try {
			prop = new Properties();
			InputStream ip = this.getClass().getClassLoader().getResourceAsStream("config_login.properties");
			prop.load(ip);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void initialization() {
		String browserName = prop.getProperty("browser");
		if (browserName.equals("Chrome")) {
			WebDriverManager.chromedriver().setup();
			DesiredCapabilities caps = new DesiredCapabilities();
			ChromeOptions options = new ChromeOptions();
			options.addArguments("incognito");  // ChromeOptions for starting chrome in incognito mode

			caps.setCapability(ChromeOptions.CAPABILITY, options);
			// other capability declarations
			caps.setCapability("browser", "Chrome");
			caps.setCapability("browser_version", "latest");
			caps.setCapability("os", "Windows");
			caps.setCapability("os_version", "10");
//			capabilities.getCapabilityNames();
//			capabilities.getPlatform();
			//System.out.println(capabilities.getCapability(capabilityName));
			//System.out.println(capabilities.);
			driver = new ChromeDriver(options);
			
			
		} else if (browserName.equals("FireFox")) {
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
		} else if (browserName.equals("IE")) {
			WebDriverManager.iedriver().setup();
			driver = new InternetExplorerDriver();
		}
		
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.get(prop.getProperty("URL"));
		driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	}
	
	public static void waitForPageToLoad() {
	    ExpectedCondition<Boolean> javascriptDone = new ExpectedCondition<Boolean>() {
	        public Boolean apply(WebDriver d) {
	            try {
	                return ((JavascriptExecutor) driver).executeScript("return document.readyState").equals("complete");
	            } catch (Exception e) {
	                return Boolean.FALSE;
	            }
	        }
	    };
	    WebDriverWait wait = new WebDriverWait(driver, 40);
	    wait.until(javascriptDone);
	}
	
	public static void Refresh() throws InterruptedException {
		Thread.sleep(2000);
		driver.navigate().refresh();
		driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
	}
	
	public static void Action_dragDrop(By ele1, By ele2) throws InterruptedException {
		WebElement elem1 = element_locator(ele1);
		WebElement elem2 = element_locator(ele2);
		int x = elem1.getLocation().x;
		int y = elem1.getLocation().y;
		int a = elem2.getLocation().x;
		int b = elem2.getLocation().y;
		
//		Thread.sleep(3000);
//		Point coordinates1 = elem1.getLocation(); 
//		Point coordinates2 = elem2.getLocation(); 
//		try {
//			Robot robot = new Robot();
//		        robot.mouseMove(coordinates1.getX()+20, coordinates1.getY()+140);
//		        Thread.sleep(1000);
//		        robot.mousePress(InputEvent.BUTTON1_MASK);
//		        //robot.mouseMove(elem1.getLocation().x+elem1.getSize().width/3, elem1.getLocation().y+elem1.getSize().getHeight()/3);
//		        Thread.sleep(1000);
//
//		        robot.mouseMove(coordinates2.getX()+20,coordinates2.getY()+140);
//
//		        Thread.sleep(1000);
//		        //robot.mouseMove(elem2.getLocation().x+elem2.getSize().width/2, elem2.getLocation().y+elem2.getSize().getHeight()/2);
//
//		        robot.mouseRelease(InputEvent.BUTTON1_MASK);
//
//		        Thread.sleep(1000);
//		    } catch (Exception e) {
//		        e.printStackTrace();
//		    }
        Actions actions = new Actions(driver);
        actions.moveByOffset(x, y)
        		.moveToElement(elem1)
                .pause(Duration.ofSeconds(2))
                .clickAndHold(elem1)
                .pause(Duration.ofSeconds(1))
                .moveByOffset(a, b)
                .moveToElement(elem2)
                .pause(Duration.ofSeconds(2))
                .release().build().perform();
	}

	public static void clickJS(By locator) {
		if (element_locator(locator) != null) {
			WebElement ele = element_locator(locator);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", ele);
			((JavascriptExecutor) driver).executeScript("arguments[0].style.border='3px dotted blue'", ele);
			((JavascriptExecutor) driver).executeScript("arguments[0].click();", ele);
		}
	}
	
	public static void click(By locator) {
		if (element_locator(locator) != null) {
			WebElement ele = element_locator(locator);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", ele);
			((JavascriptExecutor) driver).executeScript("arguments[0].style.border='3px dotted blue'", ele);
			ele.click();
		}
	}
	
	
	public static String getText(By locator) {
		if (element_locator(locator) != null) {
			WebElement ele = element_locator(locator);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", ele);
			((JavascriptExecutor) driver).executeScript("arguments[0].style.border='3px dotted blue'", ele);
			return ele.getText();
		}
		else {
			return "";
		}		
	}

	public static WebElement element_locator(By locator) {
		exp_wait = new WebDriverWait(driver, 30);
		return exp_wait.until(ExpectedConditions.presenceOfElementLocated(locator));
	}
	
	public static int elementsCount(By locator) {
		List<WebElement> ele = driver.findElements(locator);
		return ele.size();
	}
	
	//Only work with css Selector
	public static int elementsCountJS(By locator) {
		String locate = locator.toString().split(": ")[1];
		//List<WebElement> ele = driver.findElements(locator);
		System.out.println("var ele = document.querySelectorAll('"+locate+"');");
		Long count = (Long)((JavascriptExecutor) driver).executeScript("var ele = document.getElementsByClassName('cardBorder').length;(ele > 0) ? ele : 0;");
		System.out.println("JS Count: "+count);
		return 5;
	}
	
	public static String IntegerConverter(String number) {
		int num = Integer.parseInt(new DecimalFormat("#").format(Double.parseDouble(number)));
		return Integer.toString(num);
	} 
	
	public static List<String> elementsText(By locator) {
		List<WebElement> ele = driver.findElements(locator);
		List<String> text = new ArrayList<>();
		for(int i=0;i<ele.size();i++) {
			text.add(ele.get(i).getText());
		}
		return text;
	}

	public static void type(By locator, String keys) {
		if (element_locator(locator) != null) {
			WebElement ele = element_locator(locator);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", ele);
			((JavascriptExecutor) driver).executeScript("arguments[0].style.border='3px dotted red'", ele);
			ele.clear();
			ele.sendKeys(keys);
		}
	}
	
	public static void typeNoClear(By locator, String keys) {
		if (element_locator(locator) != null) {
			WebElement ele = element_locator(locator);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", ele);
			((JavascriptExecutor) driver).executeScript("arguments[0].style.border='3px dotted red'", ele);
			ele.sendKeys(keys);
		}
	}
	
	public static void typeKeyboardKeys(By locator, Keys keys) {
		if (element_locator(locator) != null) {
			WebElement ele = element_locator(locator);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", ele);
			((JavascriptExecutor) driver).executeScript("arguments[0].style.border='3px dotted red'", ele);
			ele.sendKeys(keys);
		}
	}
	
	public static boolean isDisplayed(By locator) {
		if (element_locator(locator) != null) {
			WebElement ele = element_locator(locator);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", ele);
			((JavascriptExecutor) driver).executeScript("arguments[0].style.border='3px dotted red'", ele);
			return ele.isDisplayed();
		}
		else {
			return false;
		}
	}

	public static void wholeProblemDropdown(String header, int position, String value) {
		By dropdown = By.xpath("(//*[normalize-space()='" + header + "']/../../../..//mat-select)[" + position + "]");
		click(dropdown);
		By option = By.xpath("(//mat-option//*[normalize-space()='" + value + "'])[3]");
		click(option);
	}
	
	public static void episodeDropdown(String header, int position, String value) {
		By dropdown = By.xpath("(//*[normalize-space()='" + header + "']/../../../..//mat-select)[" + position + "]");
		click(dropdown);
		By option = By.xpath("//mat-option//*[normalize-space()='" + value + "']");
		click(option);
	}
	
	public static void actionClick(By locator) {
		WebElement ele = element_locator(locator);
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", ele);
		((JavascriptExecutor) driver).executeScript("arguments[0].style.border='3px dotted red'", ele);
			Actions action = new Actions(driver);
			action.click(ele).perform();
	}
	
	public static int randomNumber(int start, int end) {
		Random random = new Random();
		int randomValue = random.nextInt(start-1) + end;
		return randomValue;
	}
	
	public static void waitForStaleness(By locator) {
		WebElement ele = element_locator(locator);
		((JavascriptExecutor) driver).executeScript("arguments[0].style.border='3px dotted red'", ele);
		WebDriverWait exp_wait = new WebDriverWait(driver, 120);
		exp_wait.until(ExpectedConditions.stalenessOf(ele));
	}
	
	public static void selectIntensity(String header,String number) throws InterruptedException {
		By intensity = By.xpath("//*[normalize-space()='" + header + "']/../../../..//*[@role='slider']");
		WebElement ele = element_locator(intensity);
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", ele);
		((JavascriptExecutor) driver).executeScript("arguments[0].style.border='3px dotted red'", ele);
		Actions action = new Actions(driver);
		action.click(ele).build().perform();
		for (int i = 0; i < Integer.valueOf(number); i++) {
			action.sendKeys(Keys.ARROW_RIGHT).build().perform();
		}
	}
	
	public static void activityIntensity(int index,String number) throws InterruptedException {
		By intensity = By.xpath("(//*[normalize-space()='Current degree of difficulty']/..//*[@role='slider'])["+index+"]");
		WebElement ele = element_locator(intensity);
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", ele);
		((JavascriptExecutor) driver).executeScript("arguments[0].style.border='3px dotted red'", ele);
		Actions action = new Actions(driver);
		action.click(ele).build().perform();
		for (int i = 0; i < Integer.valueOf(number); i++) {
			action.sendKeys(Keys.ARROW_RIGHT).build().perform();
		}
	}
	
	public static void ageGroupIntensity(String agoGroup) throws InterruptedException {
		int number=0;
		By intensity = By.xpath("//*[text()='In my age group, I consider myself as ']/..//*[@role='slider']");
		WebElement ele = element_locator(intensity);
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", ele);
		((JavascriptExecutor) driver).executeScript("arguments[0].style.border='3px dotted red'", ele);
		if(agoGroup.contains("Very unfit")) {number=+1;}
		else if(agoGroup.contains("A bit unfit")) {number=+2;}
		else if(agoGroup.contains("Average, in my age group")) {number=+3;}
		else if(agoGroup.contains("Fit")) {number=+4;}
		else if(agoGroup.contains("Super-fit")) {number=+5;}
		else {number=3;}
		Actions action = new Actions(driver);
		action.click(ele).build().perform();
		for (int i = 1; i < number; i++) {
			action.sendKeys(Keys.ARROW_RIGHT).build().perform();
		}
	}
	
	public static Object[][] getTestData(String sheetName) {
		String dir = System.getProperty("user.dir");
		FileInputStream file = null;
		try {
			file = new FileInputStream(dir + TESTDATA_SHEET_PATH);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		try {
			book = WorkbookFactory.create(file);
		} catch (InvalidFormatException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		sheet = book.getSheet(sheetName);
		
		Object[][] data = new Object[sheet.getLastRowNum()][sheet.getRow(0).getLastCellNum()];
		for (int i = 0; i < sheet.getLastRowNum(); i++) {
			for (int k = 0; k < sheet.getRow(0).getLastCellNum(); k++) {
				data[i][k] = sheet.getRow(i + 1).getCell(k).toString();
			}
		}
		return data;
	}
	
	public int getRowCount(String sheetName) {
		String dir = System.getProperty("user.dir");
		FileInputStream file = null;
		try {
			file = new FileInputStream(dir + OUTPUT_SHEET_PATH);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		try {
			book = WorkbookFactory.create(file);
		} catch (InvalidFormatException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		sheet = book.getSheet(sheetName);
		int number = sheet.getLastRowNum() + 1;
		return number;
	}
	
	public static boolean writeExcel(String sheetName, int rowNum, int colNum, String value) throws IOException {
		String dir = System.getProperty("user.dir");
		FileOutputStream fos = null;
		//XSSFWorkbook workbook = null;
		XSSFSheet sheet = null;
		XSSFRow row = null;
		XSSFCell cell = null;
		FileInputStream file = null;
		try {
			file = new FileInputStream(dir + OUTPUT_SHEET_PATH);
			// System.out.println();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		try {
			book = WorkbookFactory.create(file);
		} catch (InvalidFormatException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			sheet = (XSSFSheet) book.getSheet(sheetName);
			row = sheet.getRow(rowNum);
			if (row == null)
				row = sheet.createRow(rowNum);

			cell = row.getCell(colNum);
			if (cell == null)
				cell = row.createCell(colNum);

			cell.setCellValue(value);

			fos = new FileOutputStream(dir + OUTPUT_SHEET_PATH);
			book.write(fos);
			fos.close();
		} catch (Exception ex) {
			ex.printStackTrace();
			return false;
		}
		return true;
	}

}
