package com.healen.main;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

public class LoginPage extends BasePage {
	By username = By.id("inputEmail");
	By password = By.id("inputPassword");
	By signInBtn = By.xpath("//button[text()='Sign in']");
	By forgotPassword = By.xpath("//*[text()='Click Here!']");
	
	//Invalid EmailID
	By invalidEmail = By.xpath("//*[text()=' Please enter a valid email address ']");
	By emptyEmailOrPassword = By.cssSelector("[role='alert'] strong");
	
	//Logout
	By openMenu = By.cssSelector("[src='https://healen-ui.s3.ap-south-1.amazonaws.com/assets/images/menuicon.png']");
	By logoutBtn = By.xpath("//*[text()='Logout']");
	By confirmLogout = By.xpath("//*[text()='Yes, logout!']");
	
	By loadingIcon = By.cssSelector(".loadingSection");
	By loadingIconDark = By.cssSelector(".spinner-border.text-dark");
	
	
	public String getLoginTitle() {
		return driver.getTitle();
	}
	
	public boolean invalidEmailError(String email) {
		typeNoClear(username, email);
		type(password, "test");
		return isDisplayed(invalidEmail);
	}
	
	public boolean emptyEmailError(String email) {
		type(username, email);
		type(password, "test");
		return isDisplayed(emptyEmailOrPassword);
	}
	
	public boolean emptyPasswordError(String pwd) {
		type(password, pwd);
		type(username, "test@test.com");
		return isDisplayed(emptyEmailOrPassword);
	}
	
	public String checkForgotPassword() throws InterruptedException {
		click(forgotPassword);
		Refresh();
		return driver.getCurrentUrl();
	}
	
	public String loginWithValidCredentials(String email,String pwd) throws InterruptedException {
		type(username, email);
		type(password, pwd);
		click(signInBtn);
		waitForStaleness(loadingIcon);
		Refresh();
		return driver.getCurrentUrl();
	}
}
