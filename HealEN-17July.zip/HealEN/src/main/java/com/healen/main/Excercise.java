package com.healen.main;

public enum Excercise {
	Good,Average,Bad
}
