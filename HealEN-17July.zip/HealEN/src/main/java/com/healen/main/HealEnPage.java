package com.healen.main;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class HealEnPage extends BasePage {

	By good = By.cssSelector("[src='https://healen-ui.s3.ap-south-1.amazonaws.com/assets/images/EXEF_1.png']");
	By average = By.cssSelector("[src='https://healen-ui.s3.ap-south-1.amazonaws.com/assets/images/EXEF_2.png']");
	By bad = By.cssSelector("[src='https://healen-ui.s3.ap-south-1.amazonaws.com/assets/images/EXEF_3.png']");

	By goodSmiley = By.cssSelector("[src='https://healen-ui.s3.ap-south-1.amazonaws.com/assets/images/Pain_FB_2.png']");

	By next = By.xpath("//button[contains(text(),'Next')][@type='submit']");
	By warningNext = By.xpath("(//button[contains(text(),'Next')][@type='button'])[1]");
	By issueNext = By.xpath("//button[contains(text(),'Next')][@type='button']");
	By painNext = By.xpath("(//button[contains(text(),'Next')][@type='button'])[2]");
	By painAggravatedNext = By.xpath("(//button[contains(text(),'Next')][@type='button'])[3]");
	By startSession = By.xpath("//*[text()='Start session']");
	By endSession = By.xpath("//*[text()='End Session']");
	By start = By.xpath("//*[text()=' Start '] | //*[text()=' Continue '] | //*[text()='Start session']");
	By drag1 = By.cssSelector(".cdk-drop-list.dragList>div:nth-of-type(1)");
	By drag2 = By.cssSelector(".dragInnerContainer.dragInnerContainer2 div");
	By NoRestricton = By.xpath("//*[contains(text(),'No restriction, no pain')]");
	By sessionNextBtn = By.xpath("//button[contains(text(),'Next')]");
	By questionsNextBtn = By.cssSelector(".sv-footer__complete-btn");
	By playExercise = By.xpath("//button[contains(text(),'Play exercise video')]");
	By feedbackHeader = By.xpath("//h2[contains(.,'My performance')]");
	By sessionNumber = By.cssSelector(".cardBorder.cardBorderBack:last-child p:nth-of-type(1)");
	By mobilityQues = By.xpath("//*[text()='Was your mobility restricted/painful?']");
	By mobilityQuesCount = By.cssSelector(".excerItem.sqrCheck");
	By feltQues = By.xpath("//*[text()='It felt like...']/..//*[contains(@class,'cardAny')][1]");
	By feltQuesWithSmile = By.xpath("//*[text()='It felt like... ']/..//*[contains(@class,'mat-radio-button')][1]");
	By testExerciseQues = By.xpath("(//*[contains(@class,'flex-column')]//p)[1]");
	By closeVideoPopUp = By.cssSelector("#videoSelection [aria-label='Close']");

	// Feedback scores in excel
	By data1 = By.xpath("(//h4)[1]");
	By data2 = By.xpath("(//h4)[2]");
	By data3 = By.xpath("(//h1)[1]");
	By data4 = By.xpath("(//h1)[2]");
	By data5 = By.xpath("(//h1)[3]");

	// Login
	By username = By.id("inputEmail");
	By password = By.id("inputPassword");
	By signInBtn = By.xpath("//button[text()='Sign in']");

	// Complaint
	By createComplaint = By.xpath("//*[text()='Create new complaint']");
	By pathway = By.xpath(
			"//*[text()='I have pain or other conditions / symptoms that need to be addressed']/following-sibling::*");
	By answerAll = By.xpath(
			"//*[text()='I want to answer all questions to ensure deeply personalized recommendations. This can take 10-15 minutes.']/following-sibling::*");
	By activity1 = By.cssSelector("[formcontrolname='activity1']");
	By activity2 = By.cssSelector("[formcontrolname='activity2']");
	By activity3 = By.cssSelector("[formcontrolname='activity3']");
	By complaintNext = By.xpath("//*[text()='Next']");
	By proceed = By.xpath("//*[text()='Yes, Proceed']");
	By complaintsCount = By.cssSelector(".cardBorder.cardBorderBack");
	By complaintsText = By.cssSelector(".cardBorder.cardBorderBack p:nth-of-type(1)");
	By NothingToAddBtn = By.xpath("//*[text()='Nothing to add for now']");
	By loadingIcon = By.cssSelector(".loadingSection");
	By loadingIconDark = By.cssSelector(".spinner-border.text-dark");
	
	//Diagnosis
	By diagnosisName = By.cssSelector("input[type='search']"); 
	By diagnosisComplete = By.cssSelector("input[value='Complete']");
	
	//Sudden popup 
	By suddenPopArm = By.xpath("//*[text()='If you have or suspect a radiating pain down one arm, you may select neck. We will ask you more specifically later.']");
	By suddenPopLeg = By.xpath("//*[text()='If you have or suspect a sciatica pain down the leg, you may select back. We will ask you more specifically later.']");
	By proceedPopUp = By.xpath("//*[text()='Yes, Proceed']");
	
	public static String currentSessionNumber = "";
	public static int lastRow;
	public static int sets;
	public static int painFeedback;

	public void createComplaint(String sheetName, String priorityflag, String bodyPart, String diagnosisList,String subPart,
			String painIntensity, String wholeProblemDay, String episodeDays, String flexibilityAnswer,String ageGroup,
			String neckAlignmentAnswer, String backAlignmentAnswer, String pelvisAlignmentAnswer, String diffInLegs,
			String kneeAlignmentAnswer, String kneeAlignmentAnswer2, String footAlignmentAnswer)
			throws InterruptedException, IOException {
		lastRow = getRowCount(sheetName);

		HashMap<String, String> map = new HashMap<String, String>();
		map.put("Bilateral_A_Head", "Head");
		map.put("Bilateral_C_Chest", "Chest");
		map.put("Bilateral_B_Neck", "Neck");
		map.put("Bilateral_H_UpperBack", "Upper/Middle-Back");
		map.put("Bilateral_H_Upper/Middle-Back", "Upper/Middle-Back");
		map.put("Right_E_Shoulder/Arm", "Right Shoulder/Arm");
		map.put("Left_E_Shoulder/Arm", "Left Shoulder/Arm");
		map.put("Left_F_Elbow/Forearm", "Left Elbow/Forearm");
		map.put("Left_G_Wrist/Hand", "Left Wrist/Hand");
		map.put("Right_F_Elbow/Forearm", "Right Elbow/Forearm");
		map.put("Right_G_Wrist/Hand", "Right Wrist/Hand");
		map.put("Bilateral_I_Lower-Back", "Lower-Back");
		map.put("Left_J_Pelvis/Hip", "Left Pelvis/Hip");
		map.put("Right_J_Pelvis/Hip", "Right Pelvis/Hip");
		map.put("Right_K_Thigh", "Right Thigh");
		map.put("Left_K_Thigh", "Left Thigh");
		map.put("Left_L_Knee/Leg", "Left Knee/Leg");
		map.put("Right_L_Knee/Leg", "Right Knee/Leg");
		map.put("Right_M_Ankle/Foot", "Right Ankle/Foot");
		map.put("Left_M_Ankle/Foot", "Left Ankle/Foot");
		List<String> parts = Arrays.asList(bodyPart.split(","));
		List<String> priority = Arrays.asList(priorityflag.split(","));
		List<String> subparts = Arrays.asList(subPart.split(","));
		List<String> intensity = Arrays.asList(painIntensity.split(","));
		List<String> problemDay = Arrays.asList(wholeProblemDay.split(","));
		List<String> episodeDay = Arrays.asList(episodeDays.split(","));
		List<String> diagnosis = Arrays.asList(diagnosisList.split(";"));

		if (elementsCount(complaintsCount) == 0) {
			click(pathway);
			click(answerAll);
			for (int i = 0; i < parts.size(); i++) {
				By bodypart = By.xpath("(//*[@id='" + parts.get(i) + "'])[1]");
				if(parts.get(i).contains("Bilateral_B_Neck")) {
					driver.findElement(By.id(parts.get(i))).click();
				}else {
					actionClick(bodypart);
				}
				
				List<String> diagnosisPerBodyPart = Arrays.asList(diagnosis.get(i).split(","));
				By DiagnosisBtn = By.xpath("//*[normalize-space()='"+ map.get(parts.get(i)) +"']/..//*[text()='Add Diagnosis ']");
				click(DiagnosisBtn);
				for (int j = 0; j < diagnosisPerBodyPart.size(); j++) {
					//addDiagnosis(map.get(parts.get(i)), diagnosisPerBodyPart.get(j));
						Select diagnosisSelect = new Select(driver.findElement(By.cssSelector(".select2-hidden-accessible")));
						diagnosisSelect.selectByVisibleText(diagnosisPerBodyPart.get(j));
				}
				click(diagnosisComplete); 
				
				if (priority.get(i).equals("High")) {
					setPriority(map.get(parts.get(i)));
				}
				selectIntensity(map.get(parts.get(i)), intensity.get(i));
				wholeProblemDropdown(map.get(parts.get(i)), 2, problemDay.get(i));
				episodeDropdown(map.get(parts.get(i)), 4, episodeDay.get(i));
			}
			 click(complaintNext);
			 click(proceed);
			// waitForStaleness(loadingIcon);
			specialCaseOfNeck(parts);
			specialCaseOfLowerBack(parts);
			for (int i = 1; i < subparts.size() + 1; i++) {
				By section = By.xpath("(//*[contains(@class,'subAreaCard')]/..)[1]");
				click(section);
				By sub = By.id(subparts.get(i - 1).toString());
				actionClick(sub);
			}
			clickJS(complaintNext);
			type(activity1, "Walk");
			activityIntensity(1, intensity.get(0));
			type(activity2, "Run");
			activityIntensity(2, intensity.get(0));
			type(activity3, "Sleep");
			activityIntensity(3, intensity.get(0));
			clickJS(complaintNext);
			// Questions("Within the last 6 months, have you been diagnosed or treated with
			// one of the following conditions?");
			clickJS(questionsNextBtn);
			waitForStaleness(loadingIcon);
			Refresh();
			if (driver.getCurrentUrl().contains("generic-medical-questions")) {
				writeExcel(sheetName, 1, 1, AnswerGeneralMedicalQuestionsRandomly().toString());
				clickJS(questionsNextBtn);
			} else {
				writeExcel(sheetName, 1, 1, "No Generic Medical Question asked...");
			}
			// Questions("You can describe your complaint in more detail");
			click(NothingToAddBtn);
			FlexibilityQuestion(flexibilityAnswer);
			// selectImageButtons("Flexibility ");
			ageGroupIntensity(ageGroup);
			clickJS(next);
			PostureAlignmentQuestion("Neck", neckAlignmentAnswer);
			PostureAlignmentQuestion("Back", backAlignmentAnswer);
			PostureAlignmentQuestion("Pelvis", pelvisAlignmentAnswer);
			DifferentBtwLegs(diffInLegs);
			// selectImageButtons("Neck ");
			// selectImageButtons("Back ");
			// selectImageButtons("Pelvis ");

			// Knee 1 : Bow legs-Normal-
			if (kneeAlignmentAnswer.contains("Bow legs")) {
				PostureAlignmentQuestion2("Knee", "Bow legs", kneeAlignmentAnswer.split("-")[2]);
			} else if (kneeAlignmentAnswer.contains("Normal")) {
				PostureAlignmentQuestion2("Knee", "Normal-1", kneeAlignmentAnswer.split("-")[2]);
			} else if (kneeAlignmentAnswer.contains("Knock Knees")) {
				PostureAlignmentQuestion2("Knee", "Knock Knees", kneeAlignmentAnswer.split("-")[2]);
			} else {
				PostureAlignmentQuestion2("Knee", "Let HealEn or my doctor judge for me", "1");
			}

			// Knee 2
			if (kneeAlignmentAnswer2.contains("The knees do not fully straighten out, especially in walking")) {
				PostureAlignmentQuestion2("Knee", "The knees do not fully straighten out, especially in walking",
						kneeAlignmentAnswer.split("-")[2]);
			} else if (kneeAlignmentAnswer2.contains("Normal")) {
				PostureAlignmentQuestion2("Knee", "Normal-2", kneeAlignmentAnswer2.split("-")[2]);
			} else if (kneeAlignmentAnswer.contains("The knees over-straighten more than normal")) {
				PostureAlignmentQuestion2("Knee", "The knees over-straighten more than normal",
						kneeAlignmentAnswer2.split("-")[2]);
			} else {
				PostureAlignmentQuestion2("Knee", "Let HealEn or my doctor judge for me", "2");
			}

			// Foot
			if (kneeAlignmentAnswer.contains("The inner foot arch is flattened or absent")) {
				PostureAlignmentQuestion2("Foot", "The inner foot arch is flattened or absent",
						kneeAlignmentAnswer.split("-")[2]);
			} else if (kneeAlignmentAnswer.contains("Normal")) {
				PostureAlignmentQuestion2("Foot", "Normal-1", kneeAlignmentAnswer.split("-")[2]);
			} else if (kneeAlignmentAnswer.contains("Bunion. Tip of big toe is bent towards the other toes.")) {
				PostureAlignmentQuestion2("Foot", "Bunion. Tip of big toe is bent towards the other toes.",
						kneeAlignmentAnswer.split("-")[2]);
			} else {
				PostureAlignmentQuestion2("Foot", "Let HealEn or my doctor judge for me", "1");
			}
			/*
			 * for (int i = 4; i < 7; i++) { By cantJudge =
			 * By.xpath("(//*[text()='Let HealEn or my doctor judge for me'])[" + i + "]");
			 * click(cantJudge); }
			 */
			clickJS(next);
			waitForStaleness(loadingIcon);
		}
		// Create complaint if not exist in the list
		else if (elementsCount(complaintsCount) > 0 && elementsCount(complaintsCount) < 3 && parts.size() < 3) {
			HashMap<String, String> map2 = new HashMap<String, String>();
			map2.put("Bilateral_A_Head", "Head");
			map2.put("Bilateral_C_Chest", "Chest");
			map2.put("Bilateral_B_Neck", "Neck");
			map2.put("Bilateral_H_UpperBack", "Upper/Middle Back");
			map2.put("Bilateral_H_Upper/Middle-Back", "Upper/Middle-Back");
			map2.put("Right_E_Shoulder/Arm", "Shoulder/Arm Right");
			map2.put("Left_E_Shoulder/Arm", "Shoulder/Arm Left");
			map2.put("Left_F_Elbow/Forearm", "Elbow/Forearm Left");
			map2.put("Left_G_Wrist/Hand", "Wrist/Hand Left");
			map2.put("Right_F_Elbow/Forearm", "Elbow/Forearm Right");
			map2.put("Right_G_Wrist/Hand", "Wrist/Hand Right");
			map2.put("Bilateral_I_Lower-Back", "Lower Back");
			map2.put("Left_J_Pelvis/Hip", "Pelvis/Hip Left");
			map2.put("Right_J_Pelvis/Hip", "Pelvis/Hip Right");
			map2.put("Right_K_Thigh", "Thigh Right");
			map2.put("Left_K_Thigh", "Thigh Left");
			map2.put("Left_L_Knee/Leg", "Knee/Calf Left");
			map2.put("Right_L_Knee/Leg", "Knee/Calf Right");
			map2.put("Right_M_Ankle/Foot", "Ankle/feet Right");
			map2.put("Left_M_Ankle/Foot", "Ankle/feet Left");
			// waitForStaleness(loadingIconDark);
			List<String> existingComplaints = elementsText(complaintsText);
			List<String> nameCheck = new ArrayList<>();
			List<String> addNew = new ArrayList<>();
			
			for (int i = 0; i < parts.size(); i++) {
				nameCheck.add(map2.get(parts.get(i)));
				addNew.add(map.get(parts.get(i)));
			}
			for (int j = 0; j < nameCheck.size(); j++) {
				if (!existingComplaints.contains(nameCheck.get(j))) {
					// System.out.println("Existing :" + addNew.get(j));
					clickJS(createComplaint);
					click(pathway);
					click(answerAll);
					for (Map.Entry<String, String> e : map.entrySet()) {
						if (addNew.get(j).equals(e.getValue())) {
							By bodypart = By.xpath("(//*[@id='" + e.getKey() + "'])[1]");
							// By bodypart = By.id(e.getKey());
							if(e.getKey().contains("Bilateral_B_Neck")) {
								driver.findElement(By.id(parts.get(j))).click();
							}else {
								actionClick(bodypart);
							}
						}
					}
					
					List<String> diagnosisPerBodyPart = Arrays.asList(diagnosis.get(j).split(","));
					By DiagnosisBtn = By.xpath("//*[normalize-space()='"+ map.get(parts.get(j)) +"']/..//*[text()='Add Diagnosis ']");
					click(DiagnosisBtn);
					for (int d = 0; d < diagnosisPerBodyPart.size(); d++) {
						//addDiagnosis(map.get(parts.get(j)), diagnosisPerBodyPart.get(d));
						Select diagnosisSelect = new Select(driver.findElement(By.cssSelector(".select2-hidden-accessible")));
						diagnosisSelect.selectByVisibleText(diagnosisPerBodyPart.get(d));
					}
					click(diagnosisComplete); 
					
					if (priority.get(j).equals("High")) {
						setPriority(map.get(parts.get(j)));
					}
					selectIntensity(map.get(parts.get(j)), intensity.get(j));
					wholeProblemDropdown(map.get(parts.get(j)), 2, problemDay.get(j));
					episodeDropdown(map.get(parts.get(j)), 4, episodeDay.get(j));
					click(complaintNext);
					click(proceed);
					specialCaseOfNeck(addNew);
					specialCaseOfLowerBack(addNew);
					waitForStaleness(loadingIcon);
					for (int i = 1; i < subparts.size() + 1; i++) {
						By section = By.xpath("(//*[contains(@class,'subAreaCard')]/..)[1]");
						click(section);
						By sub = By.id(subparts.get(i - 1).toString());
						actionClick(sub);
					}
					clickJS(complaintNext);
					waitForStaleness(loadingIcon);
					Refresh();
					if (driver.getCurrentUrl().contains("generic-medical-questions")) {
						writeExcel(sheetName, 1, 1, AnswerGeneralMedicalQuestionsRandomly().toString());
						clickJS(questionsNextBtn);
					} else {
						writeExcel(sheetName, 1, 1, "No Generic Medical Question asked...");
					}
				}
			}
		}

	}

	public void createSession(String sheetName, String runSessions, String sessionTime, String exerciseFeedback)
			throws InterruptedException, IOException {
		for (int k = 0; k < Integer.valueOf(runSessions); k++) {
			lastRow = getRowCount(sheetName);
			// System.out.println("In Session " + lastRow);
			clickJS(startSession);
			Refresh();
			Thread.sleep(2000);
			// System.out.println(currentSessionNumber);
			currentSessionNumber = getText(sessionNumber).trim();
			click(start);
			Refresh();
//			By warmingBtn = By.xpath("//*[text()='Submit warmup feedback']");
//			if (elementsCount(warmingBtn)>0) {
//				clickJS(warmingBtn);
//				Thread.sleep(1000);
//				clickJS(goodSmiley);
//				clickJS(warningNext);
//				Refresh();
//			}
			if (driver.getCurrentUrl().contains("exercise-info")) {
				fillFeedback(sheetName, exerciseFeedback);
			} else {
				sessionTime(sessionTime);
				click(next);
				waitForStaleness(loadingIcon);
				Refresh();
				if (driver.getCurrentUrl().contains("session-composition")) {
					//Action_dragDrop(drag1, drag2);
					Thread.sleep(5000);
					click(next);
					waitForStaleness(loadingIcon);
				}
				Refresh();
				if (driver.getCurrentUrl().contains("exercise-info")) {
					fillFeedback(sheetName, exerciseFeedback);
				}

				if (driver.getCurrentUrl().contains("test-exercises")) {
					waitForStaleness(loadingIcon);
					By exerciseVideoProgress = By.cssSelector(".scene p.h5");
					String b[] = (getText(exerciseVideoProgress).split("/"));
					// int start = Integer.valueOf(b[0].replaceAll("\\D", ""));
					int end = Integer.valueOf(b[1].replaceAll("\\D", ""));
					// System.out.println("end " + end);
					for (int j = 0; j < end; j++) {
						writeExcel(sheetName, lastRow, 2, "NA");
						writeExcel(sheetName, lastRow, 3, "NA");
						writeExcel(sheetName, lastRow, 4, "NA");
						writeExcel(sheetName, lastRow, 5, "NA");
						By getScore = By.xpath("//h3");
						writeExcel(sheetName, lastRow, 0, currentSessionNumber);
						writeExcel(sheetName, lastRow, 1, "Test Exercise " + j+1 + ": " + getText(getScore));

						String Question = getText(testExerciseQues);
						if (Question.equals("Was your mobility restricted/painful?")) {
							writeExcel(sheetName, lastRow, 2, "No restriction, no pain");
							if (elementsCount(mobilityQuesCount) == 1) {
								click(NoRestricton);
							} else {
								for (int i = 1; i <= elementsCount(mobilityQuesCount); i++) {
									By noRestrictonMultiple = By
											.xpath("(//*[contains(text(),'No restriction, no pain')])[" + i + "]");
									click(noRestrictonMultiple);
								}
							}
							click(next);
						} else if (Question.equals("It felt like...")) {
							String answer = Questions1("It felt like...");
							writeExcel(sheetName, lastRow, 3, answer);
							click(next);
						} else if (Question.equals("It felt like... *")) {
							String answer = Questions2("It felt like...");
							writeExcel(sheetName, lastRow, 4, answer);
							click(next);
						} else if (Question.contains("Distance between my Ankles is")) {
							By distance = By.cssSelector(".descTextarea input");
							type(distance, 50+"");
							writeExcel(sheetName, lastRow, 5, "50");
							click(next);
						}else if (Question.contains("Distance between my knees is")) {
							By distance = By.cssSelector(".descTextarea input");
							type(distance, 50+"");
							
							writeExcel(sheetName, lastRow, 5, "50");
							click(next);
						}
						waitForStaleness(loadingIcon);
						lastRow = getRowCount(sheetName);
					}
//					Refresh();
//					By warmingBtn = By.xpath("//*[text()='Submit warmup feedback']");
//					if (elementsCount(warmingBtn)>0) {
//						clickJS(warmingBtn);
//						Thread.sleep(1000);
//						clickJS(goodSmiley);
//						clickJS(warningNext);
//						Refresh();
//					}
					waitForStaleness(loadingIcon);
					fillFeedback(sheetName, exerciseFeedback);
				} else {
					click(next);
					waitForStaleness(loadingIcon);
					Questions("Did you feel any muscle soreness?");
					Questions("If you felt anything else, please tell us");
					Questions("Did you sleep well/enough last night?");
					Questions("How is your mood today?");
					Questions("How is your physical health today?");
					click(questionsNextBtn);
					Thread.sleep(3000);
					Refresh();
					if (driver.getCurrentUrl().contains("test-exercises")) {
						waitForStaleness(loadingIcon);
						By exerciseVideoProgress = By.cssSelector(".scene p.h5");
						String b[] = (getText(exerciseVideoProgress).split("/"));
						// int start = Integer.valueOf(b[0].replaceAll("\\D", ""));
						int end = Integer.valueOf(b[1].replaceAll("\\D", ""));
						for (int j = 0; j < end; j++) {
							writeExcel(sheetName, lastRow, 2, "NA");
							writeExcel(sheetName, lastRow, 3, "NA");
							writeExcel(sheetName, lastRow, 4, "NA");
							writeExcel(sheetName, lastRow, 5, "NA");

							By getScore = By.xpath("//h3");
							writeExcel(sheetName, lastRow, 0, currentSessionNumber);
							writeExcel(sheetName, lastRow, 1, "Test Exercise " + j + ": " + getText(getScore));

							String Question = getText(testExerciseQues);
							if (Question.equals("Was your mobility restricted/painful?")) {
								writeExcel(sheetName, lastRow, 2, "No restriction, no pain");
								if (elementsCount(mobilityQuesCount) == 1) {
									click(NoRestricton);
								} else {
									for (int i = 1; i <= elementsCount(mobilityQuesCount); i++) {
										By noRestrictonMultiple = By
												.xpath("(//*[contains(text(),'No restriction, no pain')])[" + i + "]");
										click(noRestrictonMultiple);
									}
								}
								click(next);
							} else if (Question.equals("It felt like...")) {
								String answer = Questions1("It felt like...");
								writeExcel(sheetName, lastRow, 3, answer);
								click(next);
							} else if (Question.equals("It felt like... *")) {
								String answer = Questions2("It felt like...");
								writeExcel(sheetName, lastRow, 4, answer);
								click(next);
							} else if (Question.contains("Distance between my Ankles is")) {
								By distance = By.cssSelector(".descTextarea input");
								type(distance, "50");
								writeExcel(sheetName, lastRow, 5, "50");
								click(next);
							}
							lastRow = getRowCount(sheetName);
							waitForStaleness(loadingIcon);
						}
					}
//					Refresh();
//					if (elementsCount(warmingBtn)>0) {
//						clickJS(warmingBtn);
//						Thread.sleep(1000);
//						clickJS(goodSmiley);
//						clickJS(warningNext);
//						Refresh();
//					}
//					if (elementsCount(startSession) > 0) {
//						clickJS(startSession);
//					}
					fillFeedback(sheetName, exerciseFeedback);
				}
			}

		}
	}

	public void fillFeedback(String sheetName, String exerciseFeedback) throws InterruptedException, IOException {
		lastRow = getRowCount(sheetName);
		Thread.sleep(1000);
		By FeedbackProgress = By.cssSelector(".progressExercise p");
		String b[] = (getText(FeedbackProgress).split("/"));
		int start = Integer.valueOf(b[0].replaceAll("\\D", ""));
		int end = Integer.valueOf(b[1].replaceAll("\\D", ""));

		for (int i = start + 1; i <= end; i++) {
			try {
				if (start < end) {
					writeExcel(sheetName, lastRow, 0, currentSessionNumber);
					writeExcel(sheetName, lastRow, 1, "N/A");
					writeExcel(sheetName, lastRow, 2, "N/A");
					writeExcel(sheetName, lastRow, 3, "N/A");
					writeExcel(sheetName, lastRow, 4, "N/A");
					writeExcel(sheetName, lastRow, 5, "N/A");
					writeExcel(sheetName, lastRow, 6, "Session" + i);
					writeExcel(sheetName, lastRow, 7, getText(data1));
					writeExcel(sheetName, lastRow, 8, getText(data2));
					writeExcel(sheetName, lastRow, 9, getText(data3));
					writeExcel(sheetName, lastRow, 10, getText(data4));
					writeExcel(sheetName, lastRow, 11, getText(data5));
					writeExcel(sheetName, lastRow, 12, "N/A");
					writeExcel(sheetName, lastRow, 13, "N/A");
					writeExcel(sheetName, lastRow, 14, "N/A");
					writeExcel(sheetName, lastRow, 15, "N/A");
					writeExcel(sheetName, lastRow, 16, "N/A");
					writeExcel(sheetName, lastRow, 17, "N/A");
					writeExcel(sheetName, lastRow, 18, "N/A");
				}
			} catch (Exception e) {
				continue;
			}
			// Get Count of Sets
			sets = Integer.valueOf(getText(data5));

			// Play Feedback Exercise
			click(playExercise);
			click(sessionNextBtn);

			// Check Header of Feeback Form
			By feedbackHeader = By.xpath("//h2[text()='How was the exercise? '] | //*[text()='Exercise feedback']");
			if (getText(feedbackHeader).equals("Exercise feedback")) {

				for (int s = 1; s <= sets; s++) {
					String answer = Questions("Exercise feedback");
					writeExcel(sheetName, lastRow, 18, answer);
					click(questionsNextBtn);
					waitForStaleness(loadingIcon);

					if (s < sets) {
						click(sessionNextBtn);
						Thread.sleep(1000);
					}
				}
			} else if (getText(feedbackHeader).contains("How was the exercise?")) {
				//int exerciseFeedbackRandom = randomNumber(4, 1);
				//if (exerciseFeedbackRandom==1) {
				if (exerciseFeedback.equals("Good")) {
					if (elementsCount(good) > 0) {
						writeExcel(sheetName, lastRow, 12, "Good");
						//System.out.println("Inside how was exercise" + sets);
						for (int s = 1; s <= sets; s++) {
							ExerciseFeedback("Good");
							clickJS(next);
							Thread.sleep(1000);
							if (s < sets) {
								click(sessionNextBtn);
								Thread.sleep(1000);
							}
						}
					} else if (elementsCount(goodSmiley) > 0) {
						writeExcel(sheetName, lastRow, 12, "Good");
						clickJS(goodSmiley);
						clickJS(warningNext);
						waitForStaleness(loadingIcon);
					}
				} else if (exerciseFeedback=="2") {
					for (int s = 1; s <= sets; s++) {
					ExerciseFeedback("Average");
					writeExcel(sheetName, lastRow, 12, "Averge");
					int issueFeedbackrandom = randomNumber(4, 1);
					issueFeedback(issueFeedbackrandom);
					if (issueFeedbackrandom == 1) {
						writeExcel(sheetName, lastRow, 13, "Pain");
						
						// Question-1 : Pain
						int painFeedbackRandom = randomNumber(3, 1);
						painFeedback=painFeedbackRandom;
						//int painFeedbackRandom = 1;
						painFeedback(painFeedbackRandom);
						if (painFeedbackRandom == 1) {
							writeExcel(sheetName, lastRow, 14, "My usual pain aggravated");
						} else if (painFeedbackRandom == 2) {
							writeExcel(sheetName, lastRow, 14, "I felt pain somewhere else");
						}

						// Question-2 : My usual pain aggravated
						int painAggravatedRandom = randomNumber(4, 1);
						//int painAggravatedRandom = 1;
						painAggravatedFeedback(painAggravatedRandom);
							if (painFeedbackRandom == 1) {
								writeExcel(sheetName, lastRow, 15, "Slightly");
							} else if (painFeedbackRandom == 2) {
								writeExcel(sheetName, lastRow, 15, "Moderately");
							}else if (painFeedbackRandom == 3) {
								writeExcel(sheetName, lastRow, 15, "Strongly");
							}
							Thread.sleep(1000);			
					} else if (issueFeedbackrandom == 2) {
						writeExcel(sheetName, lastRow, 13, "Too strenuous");

						int strenuousFeedbackRandom = randomNumber(4, 1);
						strenuousFeedback(strenuousFeedbackRandom);
						if (strenuousFeedbackRandom == 1) {
							writeExcel(sheetName, lastRow, 16, "Quite strenuous/ exhausting");
						} else if (strenuousFeedbackRandom == 2) {
							writeExcel(sheetName, lastRow, 16, "Very very strenuous/ exhausting");
						} else if (strenuousFeedbackRandom == 3) {
							By repetition = By.cssSelector(".descTextarea input");
							type(repetition, 10+"");
							writeExcel(sheetName, lastRow, 16,
									"Please enter number of repetition you are able to do (describe)");
						}
					} else if (issueFeedbackrandom == 3) {
						writeExcel(sheetName, lastRow, 13, "My performance");

						int myPerformanceFeedbackRandom = randomNumber(5, 1);
						myPerformanceFeedback(myPerformanceFeedbackRandom);
						if (myPerformanceFeedbackRandom == 1) {
							writeExcel(sheetName, lastRow, 17, "My range was restricted");
						} else if (myPerformanceFeedbackRandom == 2) {
							writeExcel(sheetName, lastRow, 17, "I couldn’t follow the instructions");
							Thread.sleep(2000);
							if(elementsCount(sessionNextBtn)>0) {
								click(sessionNextBtn);
								performBetter(1);
							}
						} else if (myPerformanceFeedbackRandom == 3) {
							writeExcel(sheetName, lastRow, 17, "Exercise speed was not right");
						}else if (myPerformanceFeedbackRandom == 4) {
							writeExcel(sheetName, lastRow, 17, "I was afraid to do it as instructedt");
						}
						
					}
					if (s < sets) {
						try {
							// By video = By.xpath("//video");
							System.out.println("Sets " + sets);
							System.out.println("loop " + s);
							click(sessionNextBtn);
							Thread.sleep(1000);

						} catch (Exception e) {
							break;
						}
					}
				}
					//Bad
				} else if (exerciseFeedback=="3") {
					
						ExerciseFeedback("Bad");
						writeExcel(sheetName, lastRow, 12, "Bad");
						int issueFeedbackrandom = randomNumber(4, 1);
						issueFeedback(issueFeedbackrandom);
						if (issueFeedbackrandom == 1) {
							writeExcel(sheetName, lastRow, 13, "Pain");
							
							// Question-1 : Pain
							int painFeedbackRandom = randomNumber(3, 1);
							painFeedback=painFeedbackRandom;
							//int painFeedbackRandom = 1;
							painFeedback(painFeedbackRandom);
							if (painFeedbackRandom == 1) {
								writeExcel(sheetName, lastRow, 14, "My usual pain aggravated");
								
								// Question-2 : My usual pain aggravated
								int painAggravatedRandom = randomNumber(4, 1);
								//int painAggravatedRandom = 1;
								painAggravatedFeedback(painAggravatedRandom);
									if (painFeedbackRandom == 1) {
										writeExcel(sheetName, lastRow, 15, "Slightly");
									} else if (painFeedbackRandom == 2) {
										writeExcel(sheetName, lastRow, 15, "Moderately");
									}else if (painFeedbackRandom == 3) {
										writeExcel(sheetName, lastRow, 15, "Strongly");
									}
									Thread.sleep(1000);
							} else if (painFeedbackRandom == 2) {
								writeExcel(sheetName, lastRow, 14, "I felt pain somewhere else");
								for (int s = 1; s <= sets; s++) {
									// Question-2 : My usual pain aggravated
									int painAggravatedRandom = randomNumber(4, 1);
									// int painAggravatedRandom = 1;
									painAggravatedFeedback(painAggravatedRandom);
									if (painFeedbackRandom == 1) {
										writeExcel(sheetName, lastRow, 15, "Slightly");
									} else if (painFeedbackRandom == 2) {
										writeExcel(sheetName, lastRow, 15, "Moderately");
									} else if (painFeedbackRandom == 3) {
										writeExcel(sheetName, lastRow, 15, "Strongly");
									}
									Thread.sleep(1000);

									if (s < sets) {
										try {
											// By video = By.xpath("//video");

											System.out.println("Sets " + sets);
											System.out.println("loop " + s);
											click(sessionNextBtn);
											Thread.sleep(1000);

										} catch (Exception e) {
											break;
										}
									}
								}
							}
							
//							// Question-2 : My usual pain aggravated
//							int painAggravatedRandom = randomNumber(4, 1);
//							//int painAggravatedRandom = 1;
//							painAggravatedFeedback(painAggravatedRandom);
//								if (painFeedbackRandom == 1) {
//									writeExcel(sheetName, lastRow, 15, "Slightly");
//								} else if (painFeedbackRandom == 2) {
//									writeExcel(sheetName, lastRow, 15, "Moderately");
//								}else if (painFeedbackRandom == 3) {
//									writeExcel(sheetName, lastRow, 15, "Strongly");
//								}
//								Thread.sleep(1000);			
						} else if (issueFeedbackrandom == 2) {
							writeExcel(sheetName, lastRow, 13, "Too strenuous");

							int strenuousFeedbackRandom = randomNumber(4, 1);
							strenuousFeedback(strenuousFeedbackRandom);
							if (strenuousFeedbackRandom == 1) {
								writeExcel(sheetName, lastRow, 16, "Quite strenuous/ exhausting");
							} else if (strenuousFeedbackRandom == 2) {
								writeExcel(sheetName, lastRow, 16, "Very very strenuous/ exhausting");
							} else if (strenuousFeedbackRandom == 3) {
								By repetition = By.cssSelector(".descTextarea input");
								type(repetition, 10+"");
								writeExcel(sheetName, lastRow, 16,
										"Please enter number of repetition you are able to do (describe)");
							}
						} else if (issueFeedbackrandom == 3) {
							writeExcel(sheetName, lastRow, 13, "My performance");

							int myPerformanceFeedbackRandom = randomNumber(5, 1);
							myPerformanceFeedback(myPerformanceFeedbackRandom);
							if (myPerformanceFeedbackRandom == 1) {
								writeExcel(sheetName, lastRow, 17, "My range was restricted");
							} else if (myPerformanceFeedbackRandom == 2) {
								writeExcel(sheetName, lastRow, 17, "I couldn’t follow the instructions");
								Thread.sleep(2000);
								if(elementsCount(sessionNextBtn)>0) {
									click(sessionNextBtn);
									performBetter(1);
								}
							} else if (myPerformanceFeedbackRandom == 3) {
								writeExcel(sheetName, lastRow, 17, "Exercise speed was not right");
							}else if (myPerformanceFeedbackRandom == 4) {
								writeExcel(sheetName, lastRow, 17, "I was afraid to do it as instructedt");
							}
							
						}
				}

			} else if (getText(feedbackHeader).contains("Submit warmup feedback")) {
				for (int s = 1; s <= sets; s++) {
					By warmingBtn = By.xpath("//*[text()='Submit warmup feedback']");
					clickJS(warmingBtn);
					Thread.sleep(1000);
					By goodSmiley = By.cssSelector(
							"[src='https://healen-ui.s3.ap-south-1.amazonaws.com/assets/images/Pain_FB_2.png']");
					clickJS(goodSmiley);
					clickJS(warningNext);
				}
			}	
			lastRow = getRowCount(sheetName);
		}
	}

	public void ExerciseFeedback(String value) {
		if (value.equals("Good")) {
			clickJS(good);
		} else if (value.equals("Average")) {
			clickJS(average);
		} else if (value.equals("Bad")) {
			clickJS(bad);
		}
		click(next);
	}
	
	public void addDiagnosis(String header,String Name) {
		System.out.println(Name);
		if(!Name.equals("NA")) {
			By Diagnosis = By.xpath("//*[normalize-space()='"+ header +"']/..//*[text()='Add Diagnosis ']");
			click(Diagnosis);
			Select diagnosisList = new Select(driver.findElement(By.cssSelector(".select2-hidden-accessible")));
			diagnosisList.selectByVisibleText(Name);
		}		
	}

	public void setPriority(String header) {
		By highPriority = By.xpath("//*[normalize-space()='" + header + "']/../../..//*[text()='High priority']");
		click(highPriority);
	}

	public void specialCaseOfNeck(List<String> parts) {
		if ((parts.contains("Left_E_Shoulder/Arm") && parts.contains("Left_F_Elbow/Forearm")
				&& parts.contains("Left_G_Wrist/Hand"))
				|| (parts.contains("Left_E_Shoulder/Arm") && parts.contains("Left_F_Elbow/Forearm"))
				|| (parts.contains("Left_E_Shoulder/Arm") && parts.contains("Left_G_Wrist/Hand"))
				|| (parts.contains("Left_F_Elbow/Forearm") && parts.contains("Left_G_Wrist/Hand"))) {
			System.out.println("Inside Neck If");
			actionClick(proceedPopUp);
		} else if ((parts.contains("Right_E_Shoulder/Arm") && parts.contains("Right_F_Elbow/Forearm")
				&& parts.contains("Right_G_Wrist/Hand"))
				|| (parts.contains("Right_E_Shoulder/Arm") && parts.contains("Right_F_Elbow/Forearm"))
				|| (parts.contains("Right_E_Shoulder/Arm") && parts.contains("Right_G_Wrist/Hand"))
				|| (parts.contains("Right_F_Elbow/Forearm") && parts.contains("Right_G_Wrist/Hand"))) {
			System.out.println("Inside Neck else If");
			actionClick(proceedPopUp);
		}
	}
	
	public void specialCaseOfLowerBack(List<String> parts) {
		if((parts.contains("Left_J_Pelvis/Hip") && parts.contains("Left_K_Thigh") && parts.contains("Left_L_Knee/Leg")) 
				|| (parts.contains("Left_J_Pelvis/Hip") && parts.contains("Left_L_Knee/Leg") && parts.contains("Left_M_Ankle/Foot"))
				|| (parts.contains("Left_J_Pelvis/Hip") && parts.contains("Left_K_Thigh") && parts.contains("Left_M_Ankle/Foot"))
				|| (parts.contains("Left_K_Thigh") && parts.contains("Left_L_Knee/Leg") && parts.contains("Left_M_Ankle/Foot"))
				|| (parts.contains("Left_J_Pelvis/Hip") &&parts.contains("Left_K_Thigh"))
				|| (parts.contains("Left_J_Pelvis/Hip") &&parts.contains("Left_L_Knee/Leg"))
				|| (parts.contains("Left_J_Pelvis/Hip") &&parts.contains("Left_M_Ankle/Foot"))
				|| (parts.contains("Left_K_Thigh") &&parts.contains("Left_L_Knee/Leg"))
				|| (parts.contains("Left_K_Thigh") &&parts.contains("Left_M_Ankle/Foot"))
				|| (parts.contains("Left_L_Knee/Leg") &&parts.contains("Left_M_Ankle/Foot"))) {
			actionClick(proceedPopUp);
			}
			else if((parts.contains("Right_J_Pelvis/Hip") && parts.contains("Right_K_Thigh") && parts.contains("Right_L_Knee/Leg")) 
					|| (parts.contains("Right_J_Pelvis/Hip") && parts.contains("Right_L_Knee/Leg") && parts.contains("Right_M_Ankle/Foot"))
					|| (parts.contains("Right_J_Pelvis/Hip") && parts.contains("Right_K_Thigh") && parts.contains("Right_M_Ankle/Foot"))
					|| (parts.contains("Right_K_Thigh") && parts.contains("Right_L_Knee/Leg") && parts.contains("Right_M_Ankle/Foot"))
					|| (parts.contains("Right_J_Pelvis/Hip") &&parts.contains("Right_K_Thigh"))
					|| (parts.contains("Right_J_Pelvis/Hip") &&parts.contains("Right_L_Knee/Leg"))
					|| (parts.contains("Right_J_Pelvis/Hip") &&parts.contains("Right_M_Ankle/Foot"))
					|| (parts.contains("Right_K_Thigh") &&parts.contains("Right_L_Knee/Leg"))
					|| (parts.contains("Right_K_Thigh") &&parts.contains("Right_M_Ankle/Foot"))
					|| (parts.contains("Right_L_Knee/Leg") &&parts.contains("Right_M_Ankle/Foot"))){
				actionClick(proceedPopUp);
			}
	}
	
	public void selectImageButtons(String header) {
		By Buttons = By.xpath("(//*[text()='" + header + "']/..//*[@class='imgSelection'])");
		List<WebElement> count = driver.findElements(Buttons);
		int range = randomNumber(count.size(), 1);
		By image = By.xpath("(//*[text()='" + header + "']/..//*[@class='imgSelection'])[" + range + "]");
		clickJS(image);
	}

	/*
	 * Answers for Flexibility: Rather flexible Rather stiff Neither flexible nor
	 * stiff Let HealEn or my doctor judge for me
	 */
	public void FlexibilityQuestion(String answer) {
		By Answer = By.xpath("//*[text()='Flexibility ']/..//ul//*[contains(text(),'" + answer + "')]");
		clickJS(Answer);
	}

	public void PostureAlignmentQuestion(String header, String answer) {
		By Answer = By.xpath("//*[contains(text(),'" + header + "')]/..//ul//*[contains(text(),'" + answer + "')]");
		clickJS(Answer);
	}

	public void PostureAlignmentQuestion2(String header, String answer, String subAnswer) {
		if (answer.contains("Let HealEn or my doctor judge for me")) {
			By Answer = By.xpath("(//*[contains(text(),'" + header
					+ "')]/..//ul//*[contains(text(),'Let HealEn or my doctor judge for me')])[" + subAnswer + "]");
			clickJS(Answer);

		} else if (answer.contains("Normal")) {

			By Answer = By.xpath("(//*[contains(text(),'" + header
					+ "')]/..//ul//*[contains(text(),'Normal')]/../..//*[contains(text(),'" + subAnswer + "')])["
					+ answer.split("-")[1] + "]");
			clickJS(Answer);

		} else {
			By Answer = By.xpath("//*[contains(text(),'" + header + "')]/..//ul//*[contains(text(),'" + answer
					+ "')]/../..//*[contains(text(),'" + subAnswer + "')]");
			clickJS(Answer);
		}
	}

	public void DifferentBtwLegs(String diffInCm) {
		By diff = By.xpath("//*[text()='Pelvis ']/..//input");
		type(diff, diffInCm);
	}

	public void issueFeedback(int index) throws InterruptedException {
		/*
		 * By issues = By.
		 * xpath("(//*[contains(text(),'What was the issue?')]/../mat-checkbox//*[@class='mat-checkbox-mixedmark'])"
		 * ); List<WebElement> count = driver.findElements(issues); int range =
		 * randomNumber(count.size(), 1);
		 */
		By issue = By.xpath(
				"(//*[contains(text(),'What was the issue?')]/../mat-checkbox//*[@class='mat-checkbox-mixedmark'])["
						+ index + "]");
		clickJS(issue);
		if(index==2) {
			Thread.sleep(1000);
			clickJS(closeVideoPopUp);
		}
		click(issueNext);
	}

	public void myPerformanceFeedback(int index) throws InterruptedException {
		/*
		 * By performances = By
		 * .xpath("(//*[contains(text(),'My performance')]/../mat-checkbox//*[@class='mat-checkbox-mixedmark'])"
		 * ); List<WebElement> count = driver.findElements(performances); int range =
		 * randomNumber(count.size(), 1);
		 */
		By performance = By
				.xpath("(//*[contains(text(),'My performance')]/../mat-checkbox//*[@class='mat-checkbox-mixedmark'])["
						+ index + "]");
		clickJS(performance);
		if(index==2) {
			Thread.sleep(1000);
			clickJS(closeVideoPopUp);
		}
		click(painNext);
	}

	public void painFeedback(int index) throws InterruptedException {
		/*
		 * By pains = By.xpath(
		 * "(//*[text()='Pain']/../mat-radio-group//*[@class='mat-radio-inner-circle'])"
		 * ); List<WebElement> count = driver.findElements(pains); int range =
		 * randomNumber(count.size(), 1);
		 */
		By pain = By
				.xpath("(//*[text()='Pain']/../mat-radio-group//*[@class='mat-radio-inner-circle'])[" + index + "]");
		clickJS(pain);
		if(index==1) {
			Thread.sleep(1000);
			clickJS(closeVideoPopUp);
			
		}
		click(painNext);
	}

	public void painAggravatedFeedback(int index) {
		/*
		 * By painAggravateds = By.xpath(
		 * "(//*[text()='My usual pain aggravated ']/../mat-radio-group//*[@class='mat-radio-inner-circle'])"
		 * ); List<WebElement> count = driver.findElements(painAggravateds); int range =
		 * randomNumber(count.size(), 1);
		 */
		By painAggravated = By.xpath(
				"(//*[text()='My usual pain aggravated ']/../mat-radio-group//*[@class='mat-radio-inner-circle'])["
						+ index + "]");
		clickJS(painAggravated);
		click(painAggravatedNext);
	}
	
	public void performBetter(int index) {
		By performBetter = By.xpath(
				"(//*[text()='Could you perform better now? ']/../mat-radio-group//*[@class='mat-radio-inner-circle'])["
						+ index + "]");
		clickJS(performBetter);
		click(next);
	}
	
	public void strenuousFeedback(int index) {
		/*
		 * By painAggravateds = By
		 * .xpath("(//*[text()='Too strenuous']/../mat-radio-group//*[@class='mat-radio-inner-circle'])"
		 * ); List<WebElement> count = driver.findElements(painAggravateds); int range =
		 * randomNumber(count.size(), 1);
		 */
		By painAggravated = By.xpath(
				"(//*[text()='Too strenuous']/../mat-radio-group//*[@class='mat-radio-inner-circle'])["
						+ index + "]");
		clickJS(painAggravated);
		click(painNext);
	}

	public void sessionTime(String time) {
		By session_time = By.xpath("//*[text()='" + time + " Minutes']");
		click(session_time);
	}

	public List<String> AnswerGeneralMedicalQuestionsRandomly() {
		By Questions = By.xpath("//h5/span[@data-bind='text: koRenderedHtml']");
		elementsText(Questions);
		List<String> questionAnswer = new ArrayList<>();
		for (int i = 0; i < elementsText(Questions).size(); i++) {
			String answer = Questions(elementsText(Questions).get(i));
			questionAnswer
					.add(1 + i + ")Question: " + elementsText(Questions).get(i) + " " + "#Answer: " + answer + "\r\n");
			// System.out.println(1 + i + ")Question: " + elementsText(Questions).get(i) + "
			// " + "#Answer: " + answer);
		}
		return questionAnswer;
	}

	public String Questions(String questionName) {

		if (questionName.contains("If you felt anything else, please tell us")) {
			int range1 = randomNumber(3, 1);
			By question = By.xpath("(//span[text()='" + questionName
					+ "']/../../..//fieldset//span[@data-bind='text: koRenderedHtml'])[" + range1 + "]");
			click(question);
			return getText(question);
		} else if (questionName.contains("You can describe your complaint in more detail")) {
			// int range1 = randomNumber(5, 1);
			By question = By.xpath("(//h2[text()='" + questionName + "']/..//button[@class='surveyBorderBtn'])[5]");
			click(question);
			return getText(question);
		} else if (questionName.contains(
				"Within the last 6 months, have you been diagnosed or treated with one of the following conditions?")) {
			int range1 = randomNumber(9, 1);
			By question = By.xpath("(//span[text()='" + questionName
					+ "']/../../..//fieldset//span[@data-bind='text: koRenderedHtml'])[" + range1 + "]");
			click(question);
			return getText(question);
		} else if (questionName.contains("Exercise feedback")) {
			// int range1 = randomNumber(9, 1);
			By question = By.xpath("(//span[text()='" + questionName
					+ "']/../../..//fieldset//span[@data-bind='text: koRenderedHtml'])[" + 1 + "]");
			click(question);
			return getText(question);
		} else if (questionName.contains("How is your mood today?")) {
			By questions = By.xpath("(//span[contains(text(),'" + questionName
					+ "')]/../../..//fieldset//span[@data-bind='text: koRenderedHtml'])");
			//List<WebElement> count = driver.findElements(questions);
			// System.out.println("count "+count.size());
			//int range = randomNumber(count.size(), 1);
			By question = By.xpath("(//span[contains(text(),'" + questionName
					+ "')]/../../..//fieldset//span[@data-bind='text: koRenderedHtml'])[" + 1 + "]");
			click(question);
			return getText(question);
		}
		else if (questionName.contains("How is your physical health today?")) {
			By questions = By.xpath("(//span[contains(text(),'" + questionName
					+ "')]/../../..//fieldset//span[@data-bind='text: koRenderedHtml'])");
			List<WebElement> count = driver.findElements(questions);
			// System.out.println("count "+count.size());
			//int range = randomNumber(count.size(), 1);
			By question = By.xpath("(//span[contains(text(),'" + questionName
					+ "')]/../../..//fieldset//span[@data-bind='text: koRenderedHtml'])[" + 1 + "]");
			click(question);
			return getText(question);
		}else {
			By questions = By.xpath("(//span[contains(text(),'" + questionName
					+ "')]/../../..//fieldset//span[@data-bind='text: koRenderedHtml'])");
			List<WebElement> count = driver.findElements(questions);
			// System.out.println("count "+count.size());
			int range = randomNumber(count.size(), 1);
			By question = By.xpath("(//span[contains(text(),'" + questionName
					+ "')]/../../..//fieldset//span[@data-bind='text: koRenderedHtml'])[" + range + "]");
			click(question);
			return getText(question);
		}

	}

	public String Questions1(String questionName) {
		By questions = By.xpath("(//*[text()='" + questionName + "']/..//div[contains(@class,'cardAny')])");
		List<WebElement> count = driver.findElements(questions);
		// System.out.println("count "+count.size());
		int range = randomNumber(count.size(), 1);
		// System.out.println("Range "+range);
		By question = By
				.xpath("(//*[text()='" + questionName + "']/..//div[contains(@class,'cardAny')])[" + 1 + "]");
		click(question);
		return getText(question);
	}

	public String Questions2(String questionName) {
		By questions = By.xpath(
				"(//*[text()='" + questionName + " ']/..//mat-radio-button//*[@class='mat-radio-label-content'])");
		List<WebElement> count = driver.findElements(questions);
		// System.out.println("count "+count.size());
		int range = randomNumber(count.size(), 1);
		// System.out.println("Range "+range);
		By question = By.xpath("(//*[text()='" + questionName
				+ " ']/..//mat-radio-button//*[@class='mat-radio-label-content'])[" + 1 + "]");
		click(question);
		return "Good";
	}

}
